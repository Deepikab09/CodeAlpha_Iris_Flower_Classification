# CodeAlpha – Car Price Prediction

**Intern:** Deepika B.  
**Task:** Task 3 – Car Price Prediction with Machine Learning

## Objective
Train a regression model to estimate used-car selling prices from available car attributes.

## Dataset
The CodeAlpha task sheet specifies car-related inputs such as brand, horsepower and mileage, but does not prescribe a single dataset URL. Download a CarDekho-style vehicle CSV from the Kaggle dataset page used in the project setup:

https://www.kaggle.com/datasets/nehalbirla/vehicle-dataset-from-cardekho

Upload the CSV when prompted by the notebook. The notebook does not include fabricated records or precomputed results.

## Files
- `CodeAlpha_Car_Price_Prediction.ipynb` – Google Colab/Jupyter notebook with explanations, EDA, preprocessing, training and evaluation.
- `CodeAlpha_Car_Price_Prediction.py` – standalone Python source code.
- `README.md` – project information and run instructions.

## Requirements
Python 3.9+ and:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn
```

## Run in Google Colab
1. Open the `.ipynb` file in Google Colab.
2. Run the notebook from top to bottom.
3. Upload the downloaded CSV when the upload dialog appears.
4. Review the evaluation metrics printed at the end.

## Method
1. Load and inspect the CSV.
2. Clean column names, missing target values and duplicate rows.
3. Convert common unit-containing measurement fields to numeric values.
4. Create `car_age` when a `year` field is available.
5. Visualize price distribution and numerical correlations.
6. Split data into training and testing sets.
7. Impute missing values and one-hot encode categorical features.
8. Train a Random Forest Regressor.
9. Evaluate with MAE, RMSE and R-squared.
10. Compare actual and predicted prices.

## Notes
The model's scores depend on the dataset and split. Do not report a score until the notebook has been executed on the selected CSV. This is an educational estimate, not a professional car valuation.
