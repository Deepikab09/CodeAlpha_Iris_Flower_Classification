"""
CodeAlpha Internship – Task 3: Car Price Prediction
Intern: Deepika B.

Install dependencies:
pip install pandas numpy matplotlib seaborn scikit-learn

Run:
python CodeAlpha_Car_Price_Prediction.py

Place a CarDekho-style CSV in the same folder, or enter its path when prompted.
The CSV should contain a selling-price column named selling_price, sellingprice,
price, or sale_price.
"""

import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def clean_column_name(column):
    column = str(column).strip().lower()
    column = re.sub(r"[^a-z0-9]+", "_", column)
    return column.strip("_")


def main():
    csv_path = input("Enter the path to your car dataset CSV: ").strip()
    df = pd.read_csv(csv_path)

    print("\\nDataset shape:", df.shape)
    print(df.head())
    print("\\nMissing values:\\n", df.isnull().sum())
    print("\\nDuplicate rows:", df.duplicated().sum())

    df.columns = [clean_column_name(c) for c in df.columns]
    target_candidates = ["selling_price", "sellingprice", "price", "sale_price"]
    target_col = next((c for c in target_candidates if c in df.columns), None)

    if target_col is None:
        raise ValueError(
            "Selling-price column not found. Available columns: "
            + str(df.columns.tolist())
        )

    df[target_col] = pd.to_numeric(
        df[target_col].astype(str).str.replace(",", "", regex=False),
        errors="coerce"
    )
    df = df.dropna(subset=[target_col]).copy()
    df = df[df[target_col] > 0].drop_duplicates().reset_index(drop=True)

    # Convert common measurement fields containing units to numeric.
    for col in ["mileage", "engine", "max_power", "maxpower",
                "horsepower", "km_driven", "year", "seats"]:
        if col in df.columns:
            values = df[col].astype(str).str.replace(",", "", regex=False)
            values = pd.to_numeric(
                values.str.extract(r"([-+]?[0-9]*\\.?[0-9]+)")[0],
                errors="coerce"
            )
            if values.notna().any():
                df[col] = values

    if "year" in df.columns:
        df["car_age"] = (pd.Timestamp.today().year - df["year"]).clip(lower=0)

    # EDA plots
    plt.figure(figsize=(8, 5))
    sns.histplot(df[target_col], kde=True)
    plt.title("Distribution of Car Selling Prices")
    plt.xlabel("Selling Price")
    plt.tight_layout()
    plt.show()

    numeric_df = df.select_dtypes(include=np.number)
    if numeric_df.shape[1] >= 2:
        plt.figure(figsize=(10, 7))
        sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Between Numerical Features")
        plt.tight_layout()
        plt.show()

    X = df.drop(columns=[
        c for c in ["car_id", "id", "unnamed_0", target_col] if c in df.columns
    ])
    y = df[target_col]

    constant_cols = [c for c in X.columns if X[c].nunique(dropna=True) <= 1]
    X = X.drop(columns=constant_cols)

    if X.empty:
        raise ValueError("No usable input features found in the dataset.")

    for col in X.columns:
        if X[col].dtype == "object":
            converted = pd.to_numeric(X[col], errors="coerce")
            if converted.notna().mean() >= 0.8:
                X[col] = converted

    numeric_features = X.select_dtypes(include=np.number).columns.tolist()
    categorical_features = X.select_dtypes(exclude=np.number).columns.tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    print("\\nTraining records:", len(X_train))
    print("Testing records:", len(X_test))

    numeric_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="median"))
    ])
    categorical_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    preprocessor = ColumnTransformer([
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features)
    ])

    model = Pipeline([
        ("preprocessor", preprocessor),
        ("regressor", RandomForestRegressor(
            n_estimators=200, random_state=42, n_jobs=-1
        ))
    ])
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print("\\nMAE:", round(mean_absolute_error(y_test, y_pred), 2))
    print("RMSE:", round(np.sqrt(mean_squared_error(y_test, y_pred)), 2))
    print("R2 score:", round(r2_score(y_test, y_pred), 4))

    comparison = pd.DataFrame({
        "Actual Price": y_test.values,
        "Predicted Price": y_pred
    })
    print("\\nActual vs predicted (first 10):")
    print(comparison.head(10))

    plt.figure(figsize=(7, 5))
    sns.scatterplot(x=y_test, y=y_pred, alpha=0.6)
    low = min(float(y_test.min()), float(np.min(y_pred)))
    high = max(float(y_test.max()), float(np.max(y_pred)))
    plt.plot([low, high], [low, high], "r--")
    plt.xlabel("Actual Price")
    plt.ylabel("Predicted Price")
    plt.title("Actual vs Predicted Car Prices")
    plt.tight_layout()
    plt.show()

    sample_car = X_test.iloc[[0]].copy()
    print("\\nExample car details:")
    print(sample_car)
    print("Estimated selling price:", round(float(model.predict(sample_car)[0]), 2))
    print("Actual selling price:", round(float(y_test.iloc[0]), 2))


if __name__ == "__main__":
    main()
